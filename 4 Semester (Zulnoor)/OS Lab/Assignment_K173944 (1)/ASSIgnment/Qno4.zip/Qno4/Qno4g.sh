
ls -l | grep -e "[r][w][-]"

