apt install rename 
touch file1.sh  file1.sh file2.sh
rename 's/\.sh$/.exe/' *.sh
